#pragma once
#include "ShapeData.h"
typedef unsigned int uint;

class ShapeGenerator
{
	static ShapeData makePlaneVerts(uint dimensions);
	static ShapeData makePlaneIndices(uint dimensions);

public:

	static ShapeData makePlane(uint dimensions = 10);
	static ShapeData makeSphere(uint tesselation = 20);
	static ShapeData makeFlashlight(uint tesselation = 40);
	static ShapeData makeFlashlight2(uint tesselation = 30);
};
